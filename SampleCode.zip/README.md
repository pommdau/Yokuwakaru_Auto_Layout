# よくわかるAuto Layout iOSレスポンシブデザインをマスター

本サンプルコードのディレクトリ名は、章と節に従った命名規則になっています。
`AutoLayoutBookSampler/章番号_タイトル/節番号_各項目名`のように、章番号、節番号でディレクトリが分割されています。

アプリを実行すると、プロジェクトファイルで設定された、`Main.storyboard`が開かれます。`AppDelegate.swift`のメソッド内コメントアウトされている箇所を用いることでも、`Main.storyboard`を起動時のstoryboardとして設定することができます。
