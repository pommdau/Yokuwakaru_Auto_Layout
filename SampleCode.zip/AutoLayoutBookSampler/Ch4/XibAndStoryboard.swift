//
//  customView.swift
//  containerSample
//
//  Created by Yusuke Kawanabe on 10/4/15.
//  Copyright © 2015 Yusuke Kawanabe. All rights reserved.
//

import UIKit

class XibAndStoryboard: UIView {
    @IBOutlet var contentView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    override init(frame: CGRect) {
       super.init(frame: frame)
        self.commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    func commonInit() {
        NSBundle.mainBundle().loadNibNamed("XibAndStoryboard", owner: self, options: nil)
        self.contentView.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(self.contentView)
        
        // 親ビューの四隅に制約をはる
        self.contentView.leadingAnchor.constraintEqualToAnchor(self.leadingAnchor).active = true
        self.contentView.trailingAnchor.constraintEqualToAnchor(self.trailingAnchor).active = true
        self.contentView.topAnchor.constraintEqualToAnchor(self.topAnchor).active = true
        self.contentView.bottomAnchor.constraintEqualToAnchor(self.bottomAnchor).active = true
        self.layoutIfNeeded()
    }
    
    @IBAction func likeTapped(sender: AnyObject) {
        print("Like button tapped.")
    }
}

