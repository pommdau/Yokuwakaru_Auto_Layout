//
//  LayoutGuideViewController.swift
//  AutoLayoutBookSampler
//
//  Created by Yusuke Kawanabe on 10/19/15.
//  Copyright © 2015 Yusuke Kawanabe. All rights reserved.
//

import UIKit

class LayoutGuideViewController: UIViewController {

    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var cancelButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // レイアウトガイドを生成
        let space = UILayoutGuide()
        
        // レイアウトガイドを追加する
        view.addLayoutGuide(space)
        
        // レイアウトガイドの幅をボタンと揃える
        space.widthAnchor.constraintEqualToAnchor(saveButton.widthAnchor).active = true
        
        // レイアウトガイドを中央揃え
        space.centerXAnchor.constraintEqualToAnchor(view.centerXAnchor).active = true
        
        // 各ボタンとレイアウトガイドの水平方向の制約生成
        saveButton.trailingAnchor.constraintEqualToAnchor(space.leadingAnchor).active = true
        cancelButton.leadingAnchor.constraintEqualToAnchor(space.trailingAnchor).active = true
        view.layoutIfNeeded()
    
    }

    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
    }
}


