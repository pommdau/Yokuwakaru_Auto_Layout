//
//  SelfSizingCellViewController.swift
//  AutoLayoutBookSampler
//
//  Created by Yusuke Kawanabe on 10/27/15.
//  Copyright © 2015 Yusuke Kawanabe. All rights reserved.
//

import UIKit

class SelfSizingCellViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tableView: UITableView!
    var people = [Person]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up auto resizing cell
        self.tableView.estimatedRowHeight = 100.0
        tableView.rowHeight = UITableViewAutomaticDimension
        
        people = People.generateCellData()
        
        // Dynamic Typeのための通知受け取り
        NSNotificationCenter.defaultCenter().addObserver(self, selector:#selector(self.didChangePreferredContentSize(_:)), name: UIContentSizeCategoryDidChangeNotification, object: nil)
    }
    
    deinit {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    func didChangePreferredContentSize(notification: NSNotification) {
        tableView.reloadData()
    }
    
    // MARK: UITableViewDataSource
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // セルの取得
        guard let cell = tableView.dequeueReusableCellWithIdentifier("SelfSizingCellTableViewCell", forIndexPath: indexPath) as? SelfSizingCellTableViewCell else {
            fatalError("Your cellIdentifier is invalid")
        }
        
        // データを渡しレイアウト実行
        cell.layoutWithData(self.personForRow(indexPath.row))
        return cell
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people.count
    }

    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    // MARK: Person Array
    func personForRow(index: NSInteger) -> Person? {
        return people[index];
    }
}



