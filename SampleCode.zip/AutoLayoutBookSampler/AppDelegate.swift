//
//  AppDelegate.swift
//  containerSample
//
//  Created by Yusuke Kawanabe on 8/15/15.
//  Copyright (c) 2015 Yusuke Kawanabe. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
//        window = UIWindow()
//        
//        let storyboard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())    // 対象のStoryboardを参照
//        let firstViewController = storyboard.instantiateInitialViewController()   // Initial View Controllerに設定されたビューコントローラーを参照
//        window?.rootViewController = firstViewController    // rootViewControllerに上の行で取得したビューコントローラを設定
//        
//        // キーウィンドウに設定
//        window?.makeKeyWindow()
        return true
    }
}

